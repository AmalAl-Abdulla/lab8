package qa.edu.qu.cmps312.missioncontrolbrd;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MissionControlActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission_control);
    }
}
