package qa.edu.qu.cmps312.missioncontrolbrd;

public interface InteractionListener {

    void enableBtn(boolean enableIt);
}
