package cmps312.qu.edu.qa.systemsafetymonitorbrs;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

public class BatteryStatusReceiver extends BroadcastReceiver{
    Boolean safe = false;
    public static final String ANDROID_CHANNEL_NAME = "ANDROID CHANNEL";
    @Override
    public void onReceive(Context context, Intent intent) {

        Intent intent2 = new Intent();
        intent2.setAction("qa.edu.cmps312.safeToUse");
        if(intent.getAction()==Intent.ACTION_BATTERY_LOW) {
            Toast.makeText(context, "The System BATTERY is LOW", Toast.LENGTH_SHORT).show();
        }else if(intent.getAction()==Intent.ACTION_BATTERY_OKAY) {
            Toast.makeText(context, "The System BATTERY is OKAY", Toast.LENGTH_SHORT).show();
            safe = true;

            PendingIntent pendingIntent = PendingIntent.getActivity(context,31,intent2,PendingIntent.FLAG_UPDATE_CURRENT);
            NotificationCompat.Builder notification = new NotificationCompat.Builder(context,ANDROID_CHANNEL_NAME)
                    .setSmallIcon(R.drawable.notification_icon)
                    .setContentTitle("Battery OK")
                    .setContentText("View Mission Control BRD?")
                    .setContentIntent(pendingIntent);

            NotificationManager notificationManager=(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(31,notification.build());

        }
        intent2.putExtra("safe",safe);
        context.sendBroadcast(intent2);
    }
}
